# Andrew Lipton CS 151B Final Project car.py
from graphicsPlus import *
import time


def inPoly(pt1, poly):
    '''Sees if a click is within a certain polygon'''
    verts = poly.getPoints()
    num_verts = len(verts)

    clicked_x = pt1.getX()
    clicked_y = pt1.getY()

    result = False
    for i in range(num_verts):
        j = i - 1

        curr_point_x = verts[i].getX()
        curr_point_y = verts[i].getY()

        last_point_x = verts[j].getX()
        last_point_y = verts[j].getY()

        if (curr_point_y > clicked_y) != (last_point_y > clicked_y) and (clicked_x < (last_point_x - curr_point_x) * (clicked_y - curr_point_y) / (last_point_y - curr_point_y) + curr_point_x):
            result = not result

    return result


def update_time(start_time,time_text):
    # Get the current time
    current_time = time.localtime()
    sec_diff = current_time.tm_sec - start_time.tm_sec + (current_time.tm_min - start_time.tm_min)*60 + (current_time.tm_hour - start_time.tm_hour)*3600
    time_string = ("Timer:"+str(sec_diff))
    
    # Set the text of the Text object to the formatted time string
    time_text.setText(time_string)


def car_thing(win):
    class Car:


        # Initialize the car with its position, color, and size
        def __init__(self, x, y):
            self.x = x
            self.y = y
            self.body = Body(self.x,self.y)
            self.wheel_1 = Wheel(self.x-10,self.y)
            self.wheel_2 = Wheel(self.x+10,self.y)

            
        # Define a method for moving the car on the screen
        def move2(self, dx, dy):
            self.x += dx
            self.y += dy
            self.body.move3(dx,dy)
            self.wheel_1.move3(dx,dy)
            self.wheel_2.move3(dx,dy)


    class Body(Car):


        #initializes the body of the car
        def __init__(self,x,y):
            self.x = x
            self.y = y
            self.car_body = Rectangle(Point(x-15,y-15),Point(x+15,y-5))
            self.car_body.setFill("green")
            self.car_body.draw(win)


        #moves the body of the car
        def move3(self,dx,dy):
            self.x += dx
            self.y += dy
            self.car_body.move(dx,dy)
            make_line = Point(self.x,self.y)
            make_line.setFill("white")
            make_line.draw(win)


    class Wheel(Car):


        #initializes the wheels
        def __init__(self,x,y):
            self.x = x
            self.y = y
            self.wheel = Circle(Point(x,y),5)
            self.wheel.setFill("blue")
            self.wheel.draw(win)


        def move3(self,dx,dy):
            #moves the wheels
            self.x += dx
            self.y += dy
            self.wheel.move(dx,dy)
        

    # Creates the data track
    graph = Polygon([Point(2.0, 475.0), Point(18.0, 476.0), Point(59.0, 390.0), Point(79.0, 481.0), Point(99.0, 397.0), Point(127.0, 450.0), Point(145.0, 419.0), Point(168.0, 489.0), Point(190.0, 468.0), Point(231.0, 280.0), Point(251.0, 439.0), Point(275.0, 191.0), Point(298.0, 402.0), Point(319.0, 435.0), Point(340.0, 370.0), Point(365.0, 464.0), Point(382.0, 414.0), Point(403.0, 444.0), Point(426.0, 368.0), Point(448.0, 416.0), Point(469.0, 249.0), Point(493.0, 418.0), Point(514.0, 427.0), Point(538.0, 146.0), Point(559.0, 384.0), Point(584.0, 404.0), Point(599.0, 315.0), Point(620.0, 400.0), Point(643.0, 426.0), Point(663.0, 425.0), Point(687.0, 243.0), Point(708.0, 312.0), Point(732.0, 5.0), Point(763.0, 330.0), Point(778.0, 440.0), Point(806.0, 401.0), Point(815.0, 322.0), Point(843.0, 292.0), Point(861.0, 312.0), Point(886.0, 210.0), Point(913.0, 277.0), Point(931.0, 186.0), Point(951.0, 109.0), Point(984.0, 160.0), Point(913.0, 371.0), Point(894.0, 317.0), Point(872.0, 378.0), Point(856.0, 342.0), Point(848.0, 367.0), Point(842.0, 430.0), Point(805.0, 474.0), Point(773.0, 495.0), Point(754.0, 503.0), Point(736.0, 332.0), Point(718.0, 365.0), Point(704.0, 350.0), Point(695.0, 463.0), Point(636.0, 462.0), Point(607.0, 437.0), Point(603.0, 418.0), Point(588.0, 450.0), Point(549.0, 417.0), Point(541.0, 391.0), Point(529.0, 461.0), Point(530.0, 482.0), Point(481.0, 458.0), Point(471.0, 421.0), Point(458.0, 457.0), Point(434.0, 437.0), Point(409.0, 497.0), Point(394.0, 477.0), Point(367.0, 513.0), Point(352.0, 523.0), Point(334.0, 461.0), Point(314.0, 500.0), Point(286.0, 429.0), Point(275.0, 389.0), Point(265.0, 485.0), Point(241.0, 491.0), Point(224.0, 401.0), Point(205.0, 497.0), Point(163.0, 527.0), Point(128.0, 478.0), Point(111.0, 507.0), Point(107.0, 473.0), Point(83.0, 504.0), Point(54.0, 470.0), Point(19.0, 516.0), Point(3.0, 516.0), Point(6.0, 474.0)])
    graph.setFill("red")
    graph.draw(win)

    #Creates the ending flag
    flag = Polygon([Point(953.0, 85.0), Point(913.0, 113.0), Point(951.0, 118.0), Point(949.0, 153.0), Point(957.0, 151.0), Point(957.0, 83.0), Point(954.0, 87.0)])
    flag.move(10,25)
    flag.setFill("green")
    flag.draw(win)

    #Creates a time
    time_text = Text(Point(500, 20), "00:00:00")
    time_text.setSize(12)
    time_text.setTextColor("white")
    time_text.draw(win)

    text_1 = Text(Point(500, 80),"Use the arrow keys to move")
    text_1.setTextColor("white")
    text_1.draw(win)
    #creates the car
    car = Car(20,500)

    start_time = time.localtime()

    while True:
        # Check for key presses to move the car
        update_time(start_time,time_text)
        curr_key = win.checkKey()
        if curr_key == "Up":
            car.move2(0, -5)
            if not inPoly(Point(car.x,car.y),graph):
                car.move2(0, 5)
        elif curr_key == "Down":
            car.move2(0, 5)
            if not inPoly(Point(car.x,car.y),graph):
                car.move2(0, -5)
        elif curr_key == "Left":
            car.move2(-5, 0)
            if not inPoly(Point(car.x,car.y),graph):
                car.move2(5, 0)
        elif curr_key == "Right":
            car.move2(5, 0)
            if not inPoly(Point(car.x,car.y),graph):
                car.move2(-5, 0)
        if inPoly(Point(car.x,car.y),flag):
            time_text.setText("You Finished In "+time_text.getText()+" Seconds! (Click to Continue)")
            break
    win.getMouse()
    graph.undraw()
    text_1.undraw()
    time_text.setText("Here's Your Own Custom Wildfire Data Graph! Thanks for Checking Out My Project! (Click to end)")
    win.getMouse()