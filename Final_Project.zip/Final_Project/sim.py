# Andrew Lipton CS 151B Final Project sim.py
import numpy as np
import random
import graphicsPlus as gr
import time


# Create the window
def alive(trunk,leaves):
    '''Sets the tree to alive colors'''
    trunk.setFill("brown")
    leaves.setFill("green")


def on_fire(leaves):
    '''Sets the color of the leaves to a random on fire color'''
    leaves.setFill(random.choice(["red","orange","yellow"]))


def burnt(trunk,leaves):
    '''Sets the tree to a burnt color'''
    trunk.setFill("black")
    leaves.setFill("gray")


def draw_tree(x,y,win):
    '''Draws a single tree'''
    # Set the size of the tree
    width = 14
    height = 25
    # Draw the trunk of the tree
    trunk = gr.Rectangle(gr.Point(x-width/4, y), gr.Point(x+width/4, y-height/2))
    trunk.setFill("brown")
    trunk.draw(win)

    # Draw the leaves of the tree
    leaves = gr.Circle(gr.Point(x, y-height/2), width/2)
    leaves.setFill("green")
    leaves.draw(win)

    return (trunk, leaves)


def run_sim(win, list_of_trees, WIN_WIDTH, WIN_HEIGHT, num_generations, FIRE_PROBABILITY, FIRE_END_PROBABILITY):
    '''Uses recursion to simulate fire using non-deterministic cellular automaton'''
    GRID_WIDTH = int(WIN_WIDTH/25)
    GRID_HEIGHT = int(WIN_HEIGHT/25)

    # Set the initial state of the grid
    grid = np.zeros((GRID_WIDTH, GRID_HEIGHT), dtype=int)

    # Set the initial state of the fire
    grid[3, 4] = 1
    grid[3, 5] = 1
    grid[3, 6] = 1


    def simulate_fire(grid, i):
        # Make a copy of the grid to use for the next generation
        next_gen = grid.copy()

        if not 1 in grid:
            return

        # Iterate over every cell in the grid
        for x in range(GRID_WIDTH):
            for y in range(GRID_HEIGHT):
                # If the cell is a burning tree, set it to a burnt tree
                if grid[x, y] == 1 and random.random() < FIRE_END_PROBABILITY:
                    next_gen[x, y] = 2
                    current_tree = list_of_trees[(y * GRID_WIDTH) + x]
                    burnt(current_tree[0],current_tree[1])

                # If the cell is a tree and one of its neighbors is on fire, set it on fire with a probability of FIRE_PROBABILITY
                else:
                    try:
                        if grid[x, y] == 0 and (grid[x-1, y] == 1 or grid[x+1, y] == 1 or grid[x, y-1] == 1 or grid[x, y+1] == 1) and random.random() < FIRE_PROBABILITY:
                            next_gen[x, y] = 1
                            current_tree = list_of_trees[(y * GRID_WIDTH) + x]
                            on_fire(current_tree[1])
                    except:
                        pass

        # Update the grid with the next generation
        grid = next_gen

        time.sleep(0.2)

        # Recursively simulate the fire for the next generation
        if i < num_generations:
            simulate_fire(grid, i + 1)

    # Start simulating the fire
    simulate_fire(grid, 0)


def simulation(win):
    '''Creates the new scene and simulates fire when the user clicks'''
    WIN_WIDTH = 500
    WIN_HEIGHT = 500

    list_of_trees = []

    for i in range(int(WIN_WIDTH/25)):
        for j in range(int(WIN_HEIGHT/25)):
            list_of_trees.append(draw_tree(10 + i*25,20 +j*25,win))
    text_1 = gr.Text(gr.Point(WIN_WIDTH + 150, 80),"Number of Generations (Ex. 50): ")
    text_1.setTextColor("white")
    text_1.draw(win)
    input_box_1 = gr.Entry(gr.Point(WIN_WIDTH + 150, 100), 20)
    input_box_1.draw(win)

    text_2 = gr.Text(gr.Point(WIN_WIDTH + 150, 150),"% Chance of Fire Spreading (Ex. 30): ")
    text_2.setTextColor("white")
    text_2.draw(win)
    input_box_2 = gr.Entry(gr.Point(WIN_WIDTH + 150, 170), 20)
    input_box_2.draw(win)

    text_3 = gr.Text(gr.Point(WIN_WIDTH + 150, 230),"% Chance of Fire Ending (Ex. 20): ")
    text_3.setTextColor("white")
    text_3.draw(win)
    input_box_3 = gr.Entry(gr.Point(WIN_WIDTH + 150, 250), 20)
    input_box_3.draw(win)

    text_4 = gr.Text(gr.Point(WIN_WIDTH + 150, 330),"Type 'continue' here to continue when you click")
    text_4.setTextColor("white")
    text_4.draw(win)
    input_box_4 = gr.Entry(gr.Point(WIN_WIDTH + 150, 350), 20)
    input_box_4.draw(win)

    submit = gr.Text(gr.Point(WIN_WIDTH + 150, 300),"Click to Start")
    submit.setTextColor("white")
    submit.draw(win)

    while True:
        '''Lets the user run as many simulations as they want until they type continue and click'''
        win.getMouse()
        try:
            num_generations = int(input_box_1.getText())
            FIRE_PROBABILITY = int(input_box_2.getText())/100
            FIRE_END_PROBABILITY = int(input_box_3.getText())/100
        except:
            print("Invalid Input")
            num_generations = 50
            FIRE_PROBABILITY = 0.3
            FIRE_END_PROBABILITY = 0.2
        if input_box_4.getText() != "continue":
            for i in list_of_trees:
                alive(i[0],i[1])
            run_sim(win,list_of_trees, WIN_WIDTH,WIN_HEIGHT,num_generations,FIRE_PROBABILITY,FIRE_END_PROBABILITY)
        else:
            for i in list_of_trees:
                i[0].undraw()
                i[1].undraw()
            text_1.undraw()
            input_box_1.undraw()
            text_2.undraw()
            input_box_2.undraw()
            text_3.undraw()
            input_box_3.undraw()
            text_4.undraw()
            input_box_4.undraw()
            submit.undraw()
            break