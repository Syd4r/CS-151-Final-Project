'''Andrew Lipton CS151 Section B Final Project 12/9/22 realism.py'''
'''Creates my 3 scenes for my project, the first scene has the user click all the fire and the smoke to continue, the next scene has the user input different constants for a simulation, and the last scene has the user pilot a car using the arrow keys to reach a flag'''
from graphicsPlus import *
import time
import random
import sim
import car


def read_file():
    '''Opens the list of commands and turns them into Points and lists of vertices'''
    f = open("list.txt", "r")
    lines = f.read()
    commands = lines.splitlines()

    for h in range(len(commands)):
        commands[h] = commands[h].split(' ')
        for i in range(int(len(commands[h])/2)):
            commands[h][i] = int(commands[h][i])
            commands[h][i] = Point(commands[h][i],commands[h][i+1])
            commands[h].pop(i+1)
    return(commands)


def create_polygon(indexs,commands,recreated,fill_colors,outline,pen_width):
    '''Creates a polygon with given colors and vertices'''
    recreated.append(Polygon(commands[indexs]))
    recreated[-1].setFill(fill_colors[indexs])
    recreated[-1].setOutline(outline[indexs])
    recreated[-1].setWidth(pen_width[indexs])
    return(recreated)


def create_objects(commands,recreated, fill_colors,outline,pen_width):
    '''Creates all of my objects and puts them where I want them'''
    for i in range(len(commands)):
        recreated = create_polygon(i,commands,recreated,fill_colors,outline,pen_width)
        if i == 12:
            for f in range(5):
                recreated = create_polygon(20,commands,recreated,fill_colors,outline,pen_width)
                recreated[-1].move(f*90,f*1)
                recreated = create_polygon(21,commands,recreated,fill_colors,outline,pen_width)
                recreated[-1].move(f*40,f*2)
    recreated[0].move(-50,20)
    recreated[23].move(0,-20)
    recreated = create_polygon(17,commands,recreated,fill_colors,outline,pen_width)
    recreated[-1].move(-40,30)
    recreated = create_polygon(17,commands,recreated,fill_colors,outline,pen_width)
    recreated[-1].move(30,10)
    recreated = create_polygon(17,commands,recreated,fill_colors,outline,pen_width)
    recreated[-1].move(75,-30)
    recreated[9].move(-2,-40)
    for i in range(7):
        recreated = create_polygon(27,commands,recreated,fill_colors,outline,pen_width)
        recreated[-1].move(i*30,i*2)
    return(recreated)


def animation(recreated):
    '''Animates smoke from the fire'''
    for i in range(200):
        recreated[3].move(random.randint(-2,2),-3)
        if i == 79 or ((i+1) % 131 == 0 and i > 131):
            recreated[3].move(0,390)
        recreated[4].move(random.randint(-2,2),-3)
        if i == 66 or ((i+1) % 120 == 0 and i > 120):
            recreated[4].move(0,357)
        recreated[5].move(random.randint(-2,2),-3)
        if i == 133 or ((i+1) % 167 == 0 and i > 167):
            recreated[5].move(0,499)
        time.sleep(0.08)


def main():
    '''Runs my project'''
    on_fire = True

    commands = read_file()

    fill_colors = [color_rgb(25,5,5),color_rgb(50,10,10),color_rgb(57,10,10),'grey','grey','grey',color_rgb(255,105,0),'orange','yellow',color_rgb(74,46,4),color_rgb(112,70,16),color_rgb(112,70,16),color_rgb(112,70,16),"black",color_rgb(15,15,15),color_rgb(15,15,15),"black","black",color_rgb(112,70,16),color_rgb(82,40,6),color_rgb(62,20,6),color_rgb(132,90,36),color_rgb(255,105,0),"orange",'orange',"black",'black',color_rgb(37,10,10),"black",color_rgb(255,105,0),"orange",color_rgb(255,105,0),'orange',color_rgb(255,105,0),'orange','yellow']
    outline = ['black','black','black','black','black','black','red',color_rgb(255,150,0),color_rgb(255,210,0),'black','black','black','black',"black",color_rgb(10,10,10),color_rgb(10,10,10),"black","black","black","black","black","black","red",color_rgb(255,150,0),color_rgb(255,150,0),'black','black','black',"black",'red',color_rgb(255,150,0),'red',color_rgb(255,150,0),'red',color_rgb(255,150,0),color_rgb(255,210,0)]
    pen_width = [1,1,1,2,2,2,5,7,5,1,1,1,1,1,10,10,1,1,1,1,1,1,3,5,5,1,1,1,1,3,3,3,3,5,7,5]
    win = GraphWin('creation', 1000, 650)
    win.setBackground(color_rgb(35,15,15))
    recreated = []
    listoffire = [3,4,5,6,7,8,32,33,34,39,40,41,42,43,44,45]
    listofundrawn = []

    recreated = create_objects(commands,recreated,fill_colors,outline,pen_width)

    for i in range(len(recreated)):
        if (i in listoffire and on_fire == "False"):
            pass
        else:
            recreated[i].draw(win)

    if on_fire == "True":
        animation(recreated)

    text_1 = Text(Point(800, 600),"Click All of The Fire and Smoke")
    text_1.setTextColor("white")
    text_1.draw(win)

    while True:
        if_in = win.getMouse()
        
        if not listoffire:
            break
        for i in listoffire:
            if car.inPoly(if_in,recreated[i]) == True:
                recreated[i].undraw()
                listofundrawn.append(i)
                listoffire.remove(i)

        #rand = random.randint(0,1)
        if not listofundrawn:
            undraw = random.choice(listofundrawn)
            recreated[undraw].draw(win)
            listoffire.append(undraw)
            listofundrawn.remove(undraw)
    for i in recreated:
        i.undraw()
    text_1.undraw()
    sim.simulation(win)
    car.car_thing(win)
    win.close()


if __name__ == "__main__":
    main()